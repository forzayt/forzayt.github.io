addappid(1259420)
addappid(1259421, 1, "3a92a76d80b16038abe5b2831f554a22120535ab039dbde663a70c8b52afe11b")
setManifestid(1259421, "2120063653185364239", 0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]